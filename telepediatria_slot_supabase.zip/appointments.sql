
create table if not exists appointments (
  id uuid default gen_random_uuid() primary key,
  date date not null,
  time_slot text not null,
  patient_name text,
  patient_email text,
  status text default 'pending',
  created_at timestamp default now()
);
